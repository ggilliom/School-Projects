import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;
import static java.lang.System.*;
import java.lang.Math;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.JFrame;

public class PolygonsRunner //extends JFrame
{
  
  public static void main(String[] args)
  {
    
    Scanner garrett = new Scanner(System.in);
    System.out.println("How many points would you like your polygon to have?");
    int points = garrett.nextInt();
    IrregularPolygon shape = new IrregularPolygon(points);
    int xCor = 0;
    int yCor = 0;
    int count = 4;
    
    for(int spot = 0; spot < points; spot++)
    {
      
      System.out.println("Enter an x-coordinate: ");
      xCor = garrett.nextInt();
      System.out.println("Enter a y-coordinate: ");
      yCor = garrett.nextInt();
      
      Point where = new Point(xCor, yCor);
      
      shape.add(spot, where);
      
    }
    
    System.out.println("Area: " + shape.area());
    System.out.println("Perimeter: " + shape.perimeter());
    
   // PolygonsRunner run = new PolygonsRunner();
    
  }
  
  /*private static final int WIDTH = 800;
  private static final int HEIGHT = 600;
  
  public PolygonsRunner()
  {
    super("Polygon");

    setSize(WIDTH,HEIGHT);

    getContentPane().add(new IrregularPolygon());

    setVisible(true);

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }*/
  
  
  
}