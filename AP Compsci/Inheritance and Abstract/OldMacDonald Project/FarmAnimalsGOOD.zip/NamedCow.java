// Name: Garrett Gilliom

public class NamedCow extends Cow
{
  private String myName;
  
  public NamedCow(String type, String sound, String name)
  {
    super(type, sound);
    myName = name;
  }
  
  public String getName()
  {
    return myName; 
  }
  
  public String getType()
  {
    return super.getType() + " " + getName();
  }
}