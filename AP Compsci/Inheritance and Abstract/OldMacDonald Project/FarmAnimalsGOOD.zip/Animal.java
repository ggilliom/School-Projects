// Name: Garrett Gilliom

public interface Animal
{
  String getSound();
  String getType();
}