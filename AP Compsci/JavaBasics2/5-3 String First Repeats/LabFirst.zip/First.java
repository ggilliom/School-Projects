//(c) A+ Computer Science
//www.apluscompsci.com
//Name - Garrett Gilliom
//Date - 10/11/18


public class First
{

  
  
   public static String go( String a )
 {


     String c = "";
     
     String y = a.substring(0,1);
     int b = a.indexOf(y,1);
     
     if (b == -1)
     {
       return "No";
     }
     
     else
     {
        return "Yes";
     }
     
 
 }
}


/*

EXPECTED RUNNER OUTPUT
 
no
yes
no
no
yes
no
yes
yes
no
no


*/